package booking;

import java.util.HashMap;
import java.util.Map;

public class CabBookingService { // make it as singleton class
    // a thread safe volatile variable to store hashmap of cabIds and their availability status
    static volatile Map<Integer, Boolean> availabilityMap = new HashMap<Integer, Boolean>();
    private static CabBookingService cabBookingService;
    private CabBookingService(){
        // while starting or initialising we sync with database and get the list of all cabs and also when a cab registers it will
        // updated
        //availabilityMap = new HashMap<Integer, Boolean>();
    }

    public static CabBookingService getCabBookingServiceObject(){
        if (cabBookingService == null) {
            cabBookingService  =new CabBookingService();
        }
        return cabBookingService;
    }

    public Integer getCab(Location location, Integer threshold){
        // search db where their location x or y which is in the gap of threshold (i.e., x1-threshold <= x <= x1+threshold or
        // y1-threshold <= y <= y1+threshold from database which are available(boolean flag is driver accepts the ride)
        //asuming hashmap with list of ids and their x,y pair (location => x1, y1 (user location))
        Map<Integer, Location> map = new HashMap<Integer, Location>();
        map.put(1,new Location(1,1));
        for (Map.Entry<Integer, Location> entry : map.entrySet()) {
            if (availabilityMap.get(entry.getKey()) && check(entry.getValue(),location, threshold)) {
                    availabilityMap.put(entry.getKey(), false);
                    return entry.getKey();
            }
        }
        return -1; // handle case of this and increase threshold at the user register class
    }
    public Boolean check (Location cabLocation, Location userLocation, Integer threshold){
        double distance = Math.sqrt(Math.pow(Math.abs(cabLocation.x - userLocation.x), 2) + Math.pow(Math.abs(cabLocation.y - userLocation.y), 2));
        if (distance > threshold) {
            return false;
        }
        return true;
    }
    public void updateAvailabilityMap(Integer driverId, Boolean status){
        availabilityMap.put(driverId, status);
    }
    public void checkStatusOfTripTable(){
        //checks trip table and calls getCab for all users whose requests are in pending
    }
    public Double costOfTrip(Integer tripId){
        //get trip details from db and calculate the cost using time taken, distance, payment status
    }
}
