package booking;

public class Location {
    Integer x,y; //assuming latitude and longitude in integers
    Location(Integer x, Integer y){
        this.x = x;
        this.y = y;
    }
}