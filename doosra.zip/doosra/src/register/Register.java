package register;

public interface Register {
    // default methods which take user details like mail, phone number, kyc etc (Driver specific like license will be taken in
    // the specified class)
}
