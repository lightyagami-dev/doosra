package register;

import booking.Location;

public class DriverRegister implements Register{
    public static Integer timeInMilliSeconds = 6000;
    public Boolean updateLocation(Integer id, Location location){
        //update driver location in db periodically
    }
    public Boolean acceptTrip (Integer tripId){
        // whenever user tries to request a cab a trip is created in trip table
        // update driver db by updating driver db with unavailable and also trip table with driver id who accepted it
    }
    public Boolean completeTrip (Integer tripId){
        //get cost details from CabBookingService and as per payment status we can take payment here
        // whenever trip is completed update trip table with status complete and availability of driver
    }
}
