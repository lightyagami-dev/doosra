package register;


import booking.CabBooking;
import booking.CabBookingService;
import booking.Location;

public class UserRegister implements Register{

    public static Integer defaultThreshold = 5;

    public Integer getCab(String destination, Location location){ //from ui we get destination and location from user if user updates
        CabBookingService cabBooking = CabBookingService.getCabBookingServiceObject();
        Integer id = cabBooking.getCab(location, defaultThreshold);
        Integer threshold = defaultThreshold;
        while (id != -1){
            id = cabBooking.getCab(location, ++threshold);
        }
        return id;
    }
    public Location getLocation() {
        // using location apis we get users current location
    }

    public Boolean addPaymentOptions(){
        // will add to payments table which stores the api key which we can use to deduct in further transactions
    }
}
